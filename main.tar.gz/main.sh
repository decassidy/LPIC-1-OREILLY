#!/bin/bash

################################
# Author: Derrick Cassidy
# Version: v1.0.0
# Date: 2021-02-03
# Description: Bash Sandbox
# Usage: ./main.sh
################################

# Print text to the Terminal
echo "Hello World!"
